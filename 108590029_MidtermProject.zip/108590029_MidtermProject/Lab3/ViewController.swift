//
//  ViewController.swift
//  Lab3
//
//  Created by 朱欣雨 on 2022/3/21.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    
    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var ansLabel: UILabel!
    @IBOutlet var num_input: [UIButton]!
    @IBOutlet var op_input: [UIButton]!
    @IBOutlet var sp_input: [UIButton]!
    @IBOutlet weak var clear: UIButton!
    
    var nagative: Bool = false
    var op_s: String = ""
    let operators = CharacterSet(["+", "-", "*", "/", "%"])
    override func viewDidLoad() {
       
        super.viewDidLoad()
        
        out = ""
        ans = "0"
        // Do any additional setup after loading the view.
        for numberButton in num_input {

            numberButton.titleLabel?.font = .systemFont(ofSize: numberButton.frame.height/2)
            numberButton.layer.cornerRadius = numberButton.frame.height/2
        }
        for operationButton in op_input {
  
            operationButton.titleLabel?.font = .systemFont(ofSize: operationButton.frame.height/2)
            operationButton.layer.cornerRadius = operationButton.frame.height/2
        }
        
        for specialButton in sp_input {

            specialButton.titleLabel?.font = .systemFont(ofSize: specialButton.frame.height/2)
            specialButton.layer.cornerRadius = specialButton.frame.height/2
        }
    }

     var out: String = "" {
        didSet{
            self.Label.text = out
        }
    }
    
    var ans: String = "" {
        didSet{
            self.ansLabel.text = ans
        }
    }
    
    func updateClear() {
        if out == "" || String(out.last!).rangeOfCharacter(from: operators) != nil {
            clear.setTitle("AC", for: .normal)
        } else {
            clear.setTitle("C", for: .normal)
        }
    }
    
    
    
    @IBAction func clear(_ sender: UIButton) {
        
        if sender.currentTitle == "AC" {
            out = ""
            ans = "0"
            op_s = ""
            
        } else  if sender.currentTitle == "C" {
            ans = "0"
            
            for char in out.reversed() {
                if String(char).rangeOfCharacter(from: operators) != nil {
                    break
                }
                out = String(out.dropLast())
            }
            
            if nagative == true {
                out = String(out.dropLast())
                out = String(out.dropLast())
            }
            
            if let x = out.last {
                op_s = String(x)
            }
            
            if ans == "" || ans == "-" {
                ans = "0"
            }
        }
        
        nagative = false
        updateClear()
    }
    

    @IBAction func ans_out(_ sender: UIButton) {
        var formula = out.replacingOccurrences(of: "%", with: "/100.0")
        
       if formula.rangeOfCharacter(from: CharacterSet(["."])) == nil {
            if formula.last == ")" {
                formula = formula.dropLast() + ".0)"
            } else {
                formula = formula + ".0"
            }
        }

        let expression = NSExpression(format: formula)
        let x = expression.expressionValue(with: nil, context: nil) as! Double
        ans = x.ts
        
        clear.setTitle("AC", for: .normal)

    }
    
    
    @IBAction func op_button(_ sender: UIButton) {
    
        if out == "" {
            out = "0"
        }
        
        if let operation = sender.currentTitle {
            if op_s.rangeOfCharacter(from: operators) != nil {
                out = String(out.dropLast())
            }
                
            op_s = operation
            out += operation
            ans = "0"
        }
    }
    
    @IBAction func dot_button(_ sender: UIButton) {
        if out.last == "." {
            return
        }
        
        if out == "" {
            out = "0"
        }
        
        if let dot = sender.currentTitle {
            op_s = ""
            out += dot
            ans += dot
        }
        
    }
    
    @IBAction func num_output(_ sender: UIButton) {
        if let number = sender.currentTitle {
            if out == "" && number == "0" {
                return
            }
 
            op_s = ""
            if nagative == true {
                out = out.dropLast() + number + ")"
            } else {
                out += number
            }
            
            if ans == "0" {
                ans = number
            } else {
                ans += number
            }
        }
        
        updateClear()
        
    }
    
    @IBAction func na_button(_ sender: Any) {
        if out == "" {
            out = "0-"
            return
        }
        
        var last: String = ""
        
        if nagative == true {
            out = String(out.dropLast())
        }
        
        for char in out.reversed() {
            if String(char).rangeOfCharacter(from: operators) != nil {
                break
            }
            last += String(char)
            out = String(out.dropLast())
        }
        
        if nagative == true {
            out = String(out.dropLast())
            out = String(out.dropLast())
        } else {
            out += "(-"
        }
        
        for l in last.reversed() {
            out += String(l);
        }
        
        if nagative == false {
            out += ")"
        }
        
        nagative = !nagative
    }
    
    
    
    
    
    

}

